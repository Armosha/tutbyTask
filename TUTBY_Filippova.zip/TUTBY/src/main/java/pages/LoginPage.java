package pages;

import base.Account;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginPage extends PageObject {
    protected Logger logger;

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(id = "Username")
    private WebElement loginField;

    @FindBy(id = "Password")
    private WebElement passwordField;

    @FindBy(css = "input[value='Войти']")
    private WebElement loginButton;


    public void Login(Account account) {
        loginField.sendKeys(account.getLogin());
        passwordField.sendKeys(account.getPassword());
        loginButton.click();

    }

}
