package pages;


import base.Account;
import base.CsvSource;
import base.XmlSource;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;

public class TestPage {


    @Test
    public static void test() throws IOException {
        CsvSource sourse = new CsvSource("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.csv");
        List<Account> list = sourse.accounts();
        for (Account a :
                list) {
            System.out.println(a.getLogin());
            System.out.println(a.getPassword());
        }
    }

    @Test
    public static void tests() throws IOException, ParserConfigurationException, SAXException {
        XmlSource sours = new XmlSource("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.xml");
        List<Account> lists = sours.accounts();
        for (Account b :
                lists) {
            System.out.println(b.getLogin());
            System.out.println(b.getPassword());
        }
    }
}




