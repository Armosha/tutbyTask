package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MailPage extends PageObject {


    public MailPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = ".b-messages__subject")
    private WebElement inboxLetterSubject;

    @FindBy(xpath = ".//a[text()=\"Отправленные\"]")
    private WebElement sentCounter;

    @FindBy(css = ".b-messages__placeholder-item")
    private WebElement sentLetterTitle;


    public String inboxLetterTitle() {
        String inboxLettersTitle = inboxLetterSubject.getText();
        return inboxLettersTitle;
    }

    public void clickSentCounter() {
        sentCounter.click();
    }

    public String sentLetterCount() {
        String sentLettersTitle = sentLetterTitle.getText();
        return sentLettersTitle;
    }

}
