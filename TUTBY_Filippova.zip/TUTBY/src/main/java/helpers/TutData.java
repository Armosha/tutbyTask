package helpers;

import base.Account;
import base.CsvSource;
import base.XmlSource;
import org.testng.annotations.DataProvider;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;


public class TutData {

    @DataProvider(name = "csv")
    public static Object[][] csv() throws IOException {
        CsvSource src = new CsvSource("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.csv");
        List<Account> accounts = src.accounts();
        Object[][] accs = new Object[accounts.size()][];
        for (int i = 0; i < accounts.size(); i++) {
            accs[i] = new Object[1];
            accs[i][0] = accounts.get(i);
        }
        return accs;
    }

    @DataProvider(name = "xml")
    public static Object[][] xml() throws IOException, ParserConfigurationException, SAXException {
        XmlSource sours = new XmlSource("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.xml");
        List<Account> accounts = sours.accounts();
        Object[][] ac = new Object[accounts.size()][];
        for (int i = 0; i < accounts.size(); i++) {
            ac[i] = new Object[1];
            ac[i][0] = accounts.get(i);
        }
        return ac;
    }

}
