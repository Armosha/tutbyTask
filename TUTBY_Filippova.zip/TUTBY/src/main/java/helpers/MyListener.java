package helpers;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import java.io.File;
import java.io.IOException;

public class MyListener extends TestListenerAdapter {

    Logger logger = Logger.getLogger("tutbyLogger");
    String filePath = "D:/SCREENSHOTS/\\SCREENSHOTS\\";
    private WebDriver driver = null;


    @Override
    public void onTestStart(ITestResult result) {
        String mesg = ("**** Started test: " + "method name - " + result.getName());
        logger.info(mesg);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String mesg = ("**** Test " + " " + result.getName() + " " + "was succeed ****");
        logger.info(mesg);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String mesg = ("**** Test " + " " + result.getName() + " " + result.getMethod() + " has failed ****");
        logger.info(mesg);
        String methodName = result.getName().toString().trim();
        takeScreenShot(methodName);
    }

    public void takeScreenShot(String methodName) {
         driver = BrowserFactory.getDriver("Firefox", "https://mail.tut.by/");
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile, new File(filePath+methodName+".png"));
            System.out.println("*** Placed screenshot in "+filePath+" ***");
        } catch (IOException e) {
            e.printStackTrace();
            logger.info(e);
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String mesg = ("Test" + " " + result.getName() + " was skipped");
        logger.info(mesg);
    }

}