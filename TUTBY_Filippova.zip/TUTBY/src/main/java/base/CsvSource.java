package base;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class CsvSource implements AccountSource {


    public CsvSource(String adr) {
    }

    @Override
    public List<Account> accounts() throws IOException {


        String adr = "D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.csv";
        BufferedReader reader = null;
        String line;
        String cvsSplitBy = ",";
        List<Account> accounts = new ArrayList<Account>();

        try {
            reader = new BufferedReader(new FileReader(adr));
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(cvsSplitBy);
                Account acc = new Account();
                acc.setLogin(data[0]);
                acc.setPassword(data[1]);
                accounts.add(acc);
            }

        } catch (FileNotFoundException e) {
        }
        reader.close();
        return accounts;
    }
}