package base;

import helpers.BrowserFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.apache.log4j.Logger;

import java.io.IOException;

public class TestBase {
    public WebDriver driver;
    protected Logger logger;
    TestEmail email;

    @BeforeClass
    public void sentEmail() throws IOException {
        email = new TestEmail();
        email.send();
    }

    @BeforeMethod
    public void setUp() throws IOException {
        logger = Logger.getLogger("tutbyLogger");
        driver = BrowserFactory.getDriver("Firefox", "https://mail.tut.by/");
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}