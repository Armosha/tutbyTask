package base;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class XmlSource implements AccountSource {

    public XmlSource(String doc) {
    }

    @Override
    public List<Account> accounts() throws IOException, SAXException, ParserConfigurationException {

        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setValidating(false);
        DocumentBuilder builder = f.newDocumentBuilder();
        Document doc = builder.parse(new File("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.xml"));

        List<Account> accounts = new ArrayList<Account>();
        NodeList nodes = doc.getElementsByTagName("account");
        for (int i = 0; i < nodes.getLength(); i++) {

            Account acc = new Account();

            Node fstNode = nodes.item(i);

            if (fstNode.getNodeType() == Node.ELEMENT_NODE) {

                Element fstElmnt = (Element) fstNode;

                String data = fstElmnt.getElementsByTagName("login").item(0).getTextContent();

                acc.setLogin(data);

                String datap = fstElmnt.getElementsByTagName("password").item(0).getTextContent();

                acc.setPassword(datap);
            }
            accounts.add(acc);

        }
        return accounts;
    }

}