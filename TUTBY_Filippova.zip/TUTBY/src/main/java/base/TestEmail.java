package base;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

public class TestEmail {

    public static void send() throws IOException {

        Properties p = System.getProperties();

        p.put("mail.smtp.host", "smtp.yandex.ru");
        p.put("mail.smtp.socketFactory.port", 465);
        p.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.port", 465);

        CsvSource src = new CsvSource("D:/ИРОЧКА/JAVA/Trening/TempProject/TUTBY/src/main/resources/accountsbase.csv");
        final List<Account> accounts = src.accounts();
        for (final Account acc : accounts) {
            acc.getLogin();
            acc.getPassword();

            Session session = Session.getInstance(p,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(acc.getLogin(), acc.getPassword());
                        }
                    });
            try {
                Message msg = new MimeMessage(session);
                msg.setFrom(new InternetAddress(acc.getLogin()));
                msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(acc.getLogin()));
                msg.setSubject("greeting");
                msg.setText("Hello, world, hello java!!");
                Transport.send(msg);
            } catch (Exception e) {
                System.out.println("Something wrong" + " " + e);
            }
        }
    }
}