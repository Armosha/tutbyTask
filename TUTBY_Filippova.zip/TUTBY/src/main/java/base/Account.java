package base;

public class Account {

    private String name;
    private String password;

    public void setLogin(String name) {
        this.name = name;
    }

    public String getLogin() {
        return name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}
