import base.Account;
import base.TestBase;
import helpers.MyListener;
import helpers.TutData;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.MailPage;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;


@Listeners(MyListener.class)

public class TutPageTest extends TestBase{

    private LoginPage loginForAccount;
    private MailPage mailPageForAccount;

    @BeforeMethod
    public void setUpPages() {
        loginForAccount = new LoginPage(driver);
        mailPageForAccount = new MailPage(driver);
    }

    @Test(dataProvider = "csv", dataProviderClass = TutData.class)
    public void checkSentcsv(Account account) {
        loginForAccount.Login(account);
        mailPageForAccount.clickSentCounter();
        logger.info("Login as user :" + account.getLogin() + " " + account.getPassword());
        assertEquals("В папке «Отправленные» нет писем.", mailPageForAccount.sentLetterCount());

    }

    @Test(dataProvider = "csv", dataProviderClass = TutData.class)
    public void checkInbox(Account account) {
        loginForAccount.Login(account);
        logger.info("Login as user :" + account.getLogin() + " " + account.getPassword());
        assertEquals("greeting", mailPageForAccount.inboxLetterTitle());
    }

    @Test(dataProvider = "xml", dataProviderClass = TutData.class)
    public void checkSentxml(Account account) {
        loginForAccount.Login(account);
        mailPageForAccount.clickSentCounter();
        logger.info("Login as user :" + account.getLogin() + " " + account.getPassword());
        assertTrue(mailPageForAccount.sentLetterCount().contains("В папке «Отправленные» нет писем."));
    }

    @Test(dataProvider = "xml", dataProviderClass = TutData.class)
    public void checkInboxxml(Account account) {
        loginForAccount.Login(account);
        logger.info("Login as user :" + account.getLogin() + " " + account.getPassword());
        assertEquals("greeting", mailPageForAccount.inboxLetterTitle());
    }
}